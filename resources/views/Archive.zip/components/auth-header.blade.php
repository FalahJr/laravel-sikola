 <div class="login-brand">
     <img src="{{ asset('img/stisla-fill.svg') }}"
         alt="logo"
         width="100"
         class="shadow-light rounded-circle">
 </div>
