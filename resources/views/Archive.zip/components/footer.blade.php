<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2024 <div class="bullet"></div> Created By <a href="https://nauval.in/">
            Nawang</a>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>
